export default function page() {
    return <p>Dashboard</p>
}